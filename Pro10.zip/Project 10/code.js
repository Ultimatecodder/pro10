var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var ball = createSprite(200, 350,20,20);
ball.shapeColor= "green";
var playerpaddle=createSprite(200,380,100,10);
playerpaddle.shapeColor="yellow";

var block1= createSprite(0,100,130,70);
block1.shapeColor="blue";
var block2=createSprite(130,100,130,70);
block2.shapeColor="red";
var block3= createSprite(230,100,130,70);
block3.shapeColor="blue";
var block4= createSprite(350,100,130,70);
block4.shapeColor="red";
var block5=createSprite(0,165,130,70);
block5.shapeColor="red";
var block6=createSprite(120,165,130,70);
block6.shapeColor="blue";
var block7 = createSprite(220,165,130,70);
block7.shapeColor="red";
var block8=createSprite(340,165,130,70);
block8.shapeColor="blue";





function draw() {
  
  background("white");
  
drawSprites();
 if (keyDown("space")) {
  ball.velocityX=0;
  ball.velocityY=-4;
}
 
block1.destroy(ball);
 block2.destroy(ball);
 block3.destroy(ball);
 block4.destroy(ball);
  block5.destroy(ball);
 block6.destroy(ball);
  block7.destroy(ball);
   block8.destroy(ball);
     
  
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
